"""Exercise the shipped transaction and Windows adapter in isolated LuaJIT buffers."""
from pathlib import Path
import json
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/expanded-stat-editor'))
from lua_runtime import Lua51
import audit_data as a
def long(s):return '[====['+s+']====]'
FIXTURE=r'''
local ffi=require('ffi')
local f=assert(io.open(data_path..'/generated_entities.dl_bin','rb'));local entity=f:read('*a');f:close()
local groups={};local extent=0
for _,s in ipairs(profile.components)do
 local last=s.group+28+s.count*16+s.record_count*s.stride
 groups[s.group]=entity:sub(s.group+1,last);extent=math.max(extent,last)
end
entity=nil;collectgarbage('collect')
local module=ffi.cast('uint8_t *',0x200000000)
local function bytes(p)local a=ffi.new('uintptr_t[1]',ffi.cast('uintptr_t',p));return ffi.string(a,8)end
local function u32(p,o)return tonumber(ffi.cast('uint32_t *',p+o)[0])end
local function f32(p,o)return tonumber(ffi.cast('float *',p+o)[0])end
local function fixture(gas)
 collectgarbage('collect')
 local api=make_api();api.kept={};api.gas_required=gas or false
 local hold={}
 local en=ffi.new('uint8_t[?]',extent);hold[#hold+1]=en;local base=ffi.cast('uint8_t *',en)
 for offset,s in pairs(groups)do ffi.copy(base+offset,s,#s)end
 local owner=ffi.new('uint8_t[8]');hold[#hold+1]=owner;local ownerp=ffi.cast('uint8_t *',owner)
 local slots=ffi.new('uint64_t[3]');hold[#hold+1]=slots
 local refs={}
 for i,s in ipairs(profile.registries)do
  local row=ffi.new('uint8_t[?]',s.size);hold[#hold+1]=row
  local p=ffi.cast('uint8_t *',row);ffi.copy(p,unhex(s.original),s.size);slots[i-1]=ffi.cast('uintptr_t',p)
  refs[i]={p=p,slot=ffi.cast('uint8_t *',slots)+(i-1)*8,spec=s}
 end
 local status=ffi.new('uint8_t[152]');hold[#hold+1]=status
 local acid=ffi.cast('uint8_t *',status);ffi.cast('uint32_t *',acid)[0]=55
 ffi.copy(acid+16,unhex(profile.acid_signature),24);ffi.cast('float *',acid+40)[0]=gas and 15 or 1
 slots[2]=ffi.cast('uintptr_t',acid)
 local status_slot=ffi.cast('uint8_t *',slots)+16
 local read=api.read
 api.read=function(p,n)
  if p==module+0x346bf98 then assert(n==8);return bytes(ownerp)end
  if p==ownerp+0xf12bd8 then assert(n==8);return bytes(base+26151684)end
  if p==module+profile.status_slot then assert(n==8);return read(status_slot,n)end
  for _,pin in ipairs(profile.pins)do if p==module+pin.rva then assert(n==#pin.bytes/2);return unhex(pin.bytes)end end
  for _,r in ipairs(refs)do if p==module+r.spec.slot then assert(n==8);return read(r.slot,n)end end
  return read(p,n)
 end
 api.registry_access=function(m,p)
  assert(m==module)
  for _,r in ipairs(refs)do if p==module+r.spec.slot then return true end end
  return false
 end
 api.publish=function(m,p,old,new)
  if not api.registry_access(m,p)or api.read(p,8)~=bytes(old)then return false end
  for _,r in ipairs(refs)do if p==module+r.spec.slot then ffi.cast('uintptr_t *',r.slot)[0]=ffi.cast('uintptr_t',new);return true end end
  return false
 end
 return api,hold,base,refs,acid,status_slot
end
local function snapshot(api,base,refs,acid,status_slot)
 local out={}
 for offset,s in pairs(groups)do out[offset]=api.read(base+offset,#s)end
 for i,r in ipairs(refs)do out['row'..i]=api.read(r.p,r.spec.size);out['slot'..i]=api.read(module+r.spec.slot,8)end
 out.acid=api.read(acid,152);out.acid_slot=api.read(status_slot,8)
 return out
end
local function same(a,b,label)for k,v in pairs(a)do assert(b[k]==v,label..' changed '..tostring(k))end end
local count=0
local function reject(label,change)
 local api,hold,base,refs,acid,status_slot=fixture()
 change(api,base,refs,acid,status_slot)
 local before=snapshot(api,base,refs,acid,status_slot)
 local ok,why=patch.apply(api,ffi.cast('void *',module))
 assert(not ok,label..' succeeded')
 same(before,snapshot(api,base,refs,acid,status_slot),label)
 count=count+1
end
for _,gas in ipairs({false,true})do
 local api,hold,base,refs,acid,status_slot=fixture(gas)
 local before=snapshot(api,base,refs,acid,status_slot)
 assert(patch.apply(api,ffi.cast('void *',module)))
 local m=profile.components[1];local magazine=base+m.group+28+m.count*16+m.index*m.stride
 assert(u32(magazine,136)==70 and u32(magazine,140)==5 and u32(magazine,144)==7 and u32(magazine,148)==7)
 local w=profile.components[3];local weapon=base+w.group+28+w.count*16+w.index*w.stride
 assert(math.abs(f32(weapon,104)-0.9)<0.000001,'Default sway did not become0.9')
 local d=api.pointer(api.read(module+profile.registries[1].slot,8),0)
 assert(u32(d,4)==90 and u32(d,8)==30)
 assert(u32(d,12)==3 and u32(d,16)==3 and u32(d,20)==2 and u32(d,24)==0)
 assert(u32(d,44)==55 and f32(d,48)==1 and api.read(d+52,24)==string.rep('\0',24))
 local p=api.pointer(api.read(module+profile.registries[2].slot,8),0)
 assert(f32(p,32)==1000 and math.abs(f32(p,40)-0.3)<0.000001)
 assert(f32(acid,40)==15 and api.read(acid,40)==before.acid:sub(1,40)and api.read(acid+44,108)==before.acid:sub(45))
 assert(api.read(status_slot,8)==before.acid_slot,'Status registry must not be replaced')
 for i,r in ipairs(refs)do assert(api.read(r.p,r.spec.size)==before['row'..i],'Serialized shared row changed')end
 assert(#api.kept==2);collectgarbage('collect');assert(u32(d,44)==55 and f32(p,32)==1000)
 -- Restore only our requested capacity to prove every other entity byte stayed intact.
 ffi.cast('uint32_t *',magazine+136)[0]=35
 ffi.cast('float *',weapon+104)[0]=1
 for offset,s in pairs(groups)do assert(api.read(base+offset,#s)==s,'Unrelated entity mutation')end
 count=count+1
end
for _,s in ipairs(profile.components)do
 reject(s.label..' checksum',function(api,base)local p=base+s.group+28+s.count*16+s.index*s.stride;p[0]=(p[0]+1)%256 end)
 reject(s.label..' duplicate owner',function(api,base)ffi.copy(base+s.group+28,unhex(s.owner),8);ffi.cast('uint32_t *',base+s.group+36)[0]=s.index end)
end
reject('native pin',function(api)local read=api.read;api.read=function(p,n)if p==module+profile.pins[1].rva then return string.rep('\0',n)end;return read(p,n)end end)
reject('damage unknown',function(api,base,refs)refs[1].p[4]=1 end)
reject('projectile unknown',function(api,base,refs)refs[2].p[32]=1 end)
reject('registry permissions',function(api)api.registry_access=function()return false end end)
reject('component permissions',function(api)api.data_access=function()return false end end)
reject('allocation failure',function(api)api.owned_copy=function()error('allocation failed')end end)
reject('clone corruption',function(api)local alloc=api.owned_copy;api.owned_copy=function(s)local p=alloc(s);p[0]=0;return p end end)
reject('acid id',function(api,base,refs,acid)acid[0]=54 end)
reject('acid signature',function(api,base,refs,acid)acid[32]=1 end)
reject('acid payload',function(api,base,refs,acid)acid[80]=1 end)
reject('acid unknown duration',function(api,base,refs,acid)ffi.cast('float *',acid+40)[0]=2 end)
reject('gas claimed without duration',function(api)api.gas_required=true end)
reject('acid ownership race',function(api)
 local read=api.read;local seen=0
 api.read=function(p,n)if p==module+profile.status_slot then seen=seen+1;if seen==2 then return string.rep('\0',8)end end;return read(p,n)end
end)
for failure=1,2 do
 reject('partial component write '..failure,function(api)
  local write=api.write_attachment;local writes=0
  api.write_attachment=function(p,s)writes=writes+1;if writes==failure then assert(api.write(p,s:sub(1,#s-1)));return false end;return write(p,s)end
 end)
 reject('publication failure '..failure,function(api)
  local publish=api.publish;local writes=0
  api.publish=function(...)writes=writes+1;if writes==failure then return false end;return publish(...)end
 end)
 reject('publication succeeded/readback failure '..failure,function(api)
  local publish=api.publish;local writes=0
  api.publish=function(...)writes=writes+1;local ok=publish(...);if writes==failure then return false end;return ok end
 end)
end
reject('partial third component write (Acid Storm duration)',function(api)
 local write=api.write_attachment;local writes=0
 api.write_attachment=function(p,s)writes=writes+1;if writes==3 then assert(api.write(p,s:sub(1,#s-1)));return false end;return write(p,s)end
end)
-- Foreign changes must be retained, even when they prevent complete rollback.
do
 local api,hold,base,refs,acid=fixture()
 local publish=api.publish;local calls=0
 api.publish=function(...)
  calls=calls+1;if calls==1 then acid[80]=1;return false end
  return publish(...)
 end
 local ok,reason=patch.apply(api,module)
 assert(not ok and reason:find('restored=false',1,true)and acid[80]==1,'Foreign mutation overwritten')
 count=count+1
end
-- Actual Windows adapter, only allocations in this isolated process.
do
 ffi.cdef[[void *VirtualAlloc(void *,size_t,uint32_t,uint32_t);int VirtualFree(void *,size_t,uint32_t);]]
 local k=ffi.load('kernel32');local block=k.VirtualAlloc(nil,16384,0x3000,4);assert(block~=nil)
 local slot=ffi.cast('uint8_t *',block);local fake=slot-profile.registries[1].slot
 local api=make_api();api.kept={}
 local old=api.owned_copy(unhex(profile.registries[1].original));local new=api.owned_copy(unhex(profile.registries[1].original))
 ffi.cast('uintptr_t *',slot)[0]=ffi.cast('uintptr_t',old)
 assert(api.registry_access(fake,slot))
 assert(api.registry_access(fake,fake+profile.registries[2].slot))
 assert(not api.registry_access(fake,fake+profile.status_slot),'Status slot is not a write target')
 assert(not api.registry_access(fake,slot+8))
 assert(api.publish(fake,slot,old,new)and not api.publish(fake,slot,old,new))
 local prior=ffi.new('uint32_t[1]');assert(k.VirtualProtect(slot,4096,2,prior)~=0)
 assert(not api.registry_access(fake,slot)and not api.publish(fake,slot,new,old))
 assert(api.write_attachment(slot+16,'\1\2\3\4')and not api.writable(slot+16,4),'Original RO protection not restored')
 assert(k.VirtualProtect(slot,4096,4,prior)~=0)
 assert(api.publish(fake,slot,new,old));assert(k.VirtualFree(block,0,0x8000)~=0)
 count=count+1
end
local f=assert(io.open(report_path,'w'));f:write(count);f:close()
'''
def main():
    runtime=Lua51();source=HERE/'source'
    compiled=runtime.compile((source/'entry.lua').read_bytes(),'@mods/codex/tenderizer_armor_impl.lua')
    (HERE/'compiled.luac').write_bytes(compiled)
    prefix='local data_path='+long(a.DATA.as_posix())+'\nlocal report_path='+long((HERE/'fixture-count.txt').as_posix())+'\n'
    for var,name in [('make_api','windows.lua'),('profile','profile.lua')]:prefix+='local '+var+'=(function()\n'+(source/name).read_text()+'\nend)()\n'
    prefix+="local function unhex(s)return(s:gsub('..',function(h)return string.char(tonumber(h,16))end))end\n"
    prefix+='local patch=(function()\n'+(HERE/'core.lua').read_text()+'\nend)()\n'
    runtime.run((prefix+FIXTURE).encode(),'@tenderizer-offline-fixtures.lua')
    count=int((HERE/'fixture-count.txt').read_text())
    report=dict(result='PASS',fixtures=count,compiled_sha256=a.sha(compiled),startup='NOT RUN',loaded_resource='NOT RUN',gameplay='NOT RUN',process_access=False,deployment=False,settings=False)
    (HERE/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':main()
