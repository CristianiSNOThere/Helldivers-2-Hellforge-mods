"""Generate a guarded Tenderizer candidate from supported extracted data and saved code."""
from pathlib import Path
import importlib.util
import json
import re
import struct
import sys
import uuid

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/expanded-stat-editor'))
import audit_data as a
ENTITY=(a.DATA/'generated_entities.dl_bin').read_bytes()
_,_,TYPES=a.parse_typelib(a.DATA/'dl_library.dl_typelib')
OWNER='CE063AA33D95A812'
DESCRIPTION=('AR-61 Tenderizer magazine capacity increases from 35 to 70 rounds and bullet launch speed from 820 to 1,000 m/s. '
    'Direct and slight-angle armor penetration increase from AP2 to AP3; the other angle settings remain unchanged. '
    'Bullets apply Acid Storm to temporarily reduce enemy armor effectiveness for 15 seconds. '
    'Base sway is set to 0.9. Normal/durable damage is 90/30, with the existing 600/850 RPM settings, recoil and spread. '
    'The shared Acid Storm duration also affects its weather effect after exposure ends.')
STATUS=('Applied: AR-61 Tenderizer 70-round magazine, 1000 m/s projectile speed, direct/slight AP3 '
    '(other angles 2/0), Acid Storm on bullet hits with strength 1 and shared duration 15 seconds; '
    'base sway 0.9; 90/30 damage, 600/850 RPM, recoil, spread, spare magazines and drag unchanged.')
def literal(v):
    if isinstance(v,str):return json.dumps(v)
    if isinstance(v,bool):return str(v).lower()
    if isinstance(v,(int,float)):return repr(v)
    if isinstance(v,list):return '{'+','.join(map(literal,v))+'}'
    return '{'+','.join('['+literal(k)+']='+literal(x)for k,x in v.items())+'}'
def main():
    source=HERE/'source';source.mkdir(exist_ok=True)
    identity_path=HERE/'identity.json'
    if not identity_path.exists():identity_path.write_text(json.dumps(dict(guid=str(uuid.uuid4()),module='mods/codex/tenderizer_armor',implementation='mods/codex/tenderizer_armor_impl',global_name='TenderizerArmorV1',version='0.1.2'),indent=2)+'\n')
    identity=json.loads(identity_path.read_text())
    spec=importlib.util.spec_from_file_location('archive',ROOT/'work/flag-mod/BingusSharedLoader-main/scripts/archive.py')
    encoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(encoder)
    identity['key']=f"{encoder.resource_hash(identity['module']):016X}"
    identity['implementation_key']=f"{encoder.resource_hash(identity['implementation']):016X}"
    identity_path.write_text(json.dumps(identity,indent=2)+'\n')
    components=[]
    for name,label,edits in [('WeaponMagazineComponent','magazine',[(136,struct.pack('<I',70))]),('ProjectileWeaponComponent','fire',[]),('WeaponDataComponent','sway',[(104,struct.pack('<f',0.9))])]:
        rows,owners,meta=a.component_records(ENTITY,name,TYPES)
        own=owners[OWNER]
        assert [k for k,v in owners.items()if v['record_index']==own['record_index']]==[OWNER]
        components.append(dict(label=label,group=meta['payload_file_offset']-28,header=ENTITY[meta['payload_file_offset']-28:meta['payload_file_offset']].hex(),count=meta['map_count'],stride=meta['stride'],record_count=meta['record_count'],index=own['record_index'],owner=struct.pack('<Q',int(OWNER,16)).hex(),sha=a.sha(rows[OWNER]),edits=[dict(offset=o,bytes=b.hex())for o,b in edits]))
    projectile,_,_=a.row_table_records(a.DATA/'generated_projectile_settings.dl_bin',a.T_PROJECTILE,272,[])
    damage,_,_=a.row_table_records(a.DATA/'generated_damage_settings.dl_bin',a.T_DAMAGE,76,[])
    assert a.u32(projectile['44'],60)==135 and damage['135'][44:]==bytes(32)
    assert struct.unpack_from('<4I',damage['135'],12)==(2,2,2,0)
    changed=bytearray(damage['135']);struct.pack_into('<I',changed,4,90);struct.pack_into('<2I',changed,12,3,3);struct.pack_into('<If',changed,44,55,1)
    registries=[]
    for kind,ident,table,row,offset,after in [('damage',135,0x37c60c0,damage['135'],4,bytes(changed[4:52])),('projectile',44,0x37c7670,projectile['44'],32,struct.pack('<f',1000))]:
        registries.append(dict(label=kind,id=ident,slot=table+ident*8,size=len(row),sha=a.sha(row),offset=offset,bytes=after.hex(),original=row.hex()))
    capture=ROOT/'work/sickle-laser-ar-20261015/authorized-code-20261015T075831Z'
    metadata=json.loads((capture/'metadata.json').read_text());code=(capture/'game-text.bin').read_bytes()
    assert a.sha(code)=='373FD67E02BBF277494BFA8357ACBCBC5A7E2A309B5F0B20578C7B383996658B'
    # Every native instruction pin is checked against the already authorized saved capture.
    ranges=[(0x12a23fd,7),(0x12a2404,4),(0x12a2479,5),(0x12a247e,5),(0x13a9c95,5),(0x13aa0c3,10),
            (0x11f11d0,3),(0x11f11d3,7),(0x11f11da,4),(0x69a01e,8),(0x69a148,5)]
    pins=[dict(rva=rva,bytes=code[rva-metadata['rva']:rva-metadata['rva']+size].hex())for rva,size in ranges]
    assert bytes.fromhex(pins[7]['bytes'])==b'\x48\x8d\x0d'+struct.pack('<i',0x37c5c50-0x11f11d3-7)
    gas_source=(ROOT/'work/rapid-arc-thrower/release-repo/source/gas-overhaul/sterilizer-entry.lua').read_text()
    gas_status=re.search(r"return '(Applied: TX-41 Sterilizer[^']+)'",gas_source).group(1)
    profile=dict(components=components,registries=registries,pins=pins,status_slot=0x37c5c50+55*8,
        acid_signature='00000000000000009db958bdd7e7bc960000c03f0000803f',gas_applied=gas_status)
    (HERE/'profile.json').write_text(json.dumps(profile,indent=2)+'\n')
    (source/'profile.lua').write_text('return '+literal(profile)+'\n')
    api=(ROOT/'work/rapid-arc-thrower/release-repo/source/sickle-laser-ar/windows.lua').read_text()
    api=api.replace('SickleLaserMemoryInfoV1','TenderizerMemoryInfoV1').replace('Sickle','Tenderizer')
    api=re.sub(r'local registry_slots=\{.*?\n    \}', 'local registry_slots={['+hex(registries[0]['slot'])+']=true,['+hex(registries[1]['slot'])+']=true\n    }',api,flags=re.S)
    (source/'windows.lua').write_text(api)
    core=(ROOT/'work/sickle-double-edge-20261015/core.lua').read_text().replace('Sickle','Tenderizer')
    # Reuse the complete transaction; add the native-owned Acid Storm row as another guarded plan.
    extra='''    local slot=game+profile.status_slot
    local row=api.pointer(api.read(slot,8),0)
    if not row then fail('Expected one supported Acid Storm row; found 0')end
    local s=api.read(row,152)
    assert(api.data_access(row,152) and s and #s==152 and u32(s,0)==55,'Acid Storm ownership or permissions mismatch')
    assert(s:sub(17,40)==unhex(profile.acid_signature),'Acid Storm status fields mismatch')
    assert(u32(s,44)==0 and s:byte(49)==0 and s:sub(57,97)==string.rep('\\0',41),'Acid Storm status payload mismatch')
    local seconds=s:sub(41,44)
    assert(seconds==unhex('0000803f')or seconds==unhex('00007041'),'Unknown Acid Storm duration')
    if api.gas_required then assert(seconds==unhex('00007041'),'Gas Overhaul reported Applied without its 15-second duration')end
    local edits=seconds==unhex('0000803f')and{{offset=40,bytes='00007041'}}or{}
    plans[#plans+1]={row=row,size=152,source=s,edits=edits,label='acid_duration',proof=function()return api.read(slot,8)==api.pointer_bytes(row)end}
'''
    core=core.replace('    return plans\n',extra+'    return plans\n',1)
    core=re.sub(r"        return 'Applied: LAS-16[^\n]+",'        return '+json.dumps(STATUS),core)
    (HERE/'core.lua').write_text(core)
    startup=(ROOT/'work/rapid-arc-thrower/release-repo/source/sickle-laser-ar/startup.lua').read_text().replace('SickleLaserARV1','TenderizerArmorV1').replace('SickleLaserAR','TenderizerArmor').replace('Sickle','Tenderizer')
    startup=startup.replace("version='0.1.2'","version='0.1.2'")
    startup=re.sub(r"file:write\('TenderizerArmor v0.1.2[^\\]+", "file:write('TenderizerArmor v0.1.2 70 ROUNDS / 1000 M/S / DIRECT-SLIGHT AP3 / ACID STORM 15S / SWAY 0.9",startup)
    gate='''            local function wait_for_gas()
                local loader=rawget(_G,'CowboyBingusModLoader')
                local module_status=loader and loader.modules and loader.modules['mods/codex/sterilizer_armor_control']
                local peer=rawget(_G,'SterilizerArmorControlV1')
                local detected=peer~=nil or(module_status~=nil and module_status~='not installed')
                api.gas_required=detected
                if not detected then return end
                local started=assert(api.now,'Clock unavailable for Gas Overhaul readiness')()
                repeat
                    peer=rawget(_G,'SterilizerArmorControlV1')
                    if peer and type(peer.status)=='string'and peer.status:sub(1,8)=='Applied:'then
                        assert(peer.status==profile.gas_applied,'Unsupported Gas Overhaul Applied state. No edit applied.')
                        return
                    end
                    assert(api.now()-started<120000,'Installed companion did not become ready within 120 seconds: Gas Overhaul; no Tenderizer edits applied')
                    state.status='Waiting for installed Gas Overhaul to report Applied';log();coroutine.yield()
                until false
            end
'''
    startup=startup.replace('            for attempt=1,8 do',gate+'            for attempt=1,8 do',1)
    startup=startup.replace('if attempt==1 then wait_for_loading(15000,attempt) end','if attempt==1 then wait_for_loading(15000,attempt);wait_for_gas() end')
    (source/'startup.lua').write_text(startup)
    entry='-- HD2-Addon: '+identity['module']+'\n'
    for variable,filename in [('make_api','windows.lua'),('profile','profile.lua')]:entry+='local '+variable+'=(function()\n'+(source/filename).read_text()+'\nend)()\n'
    entry+='local patch=(function()\n'+core+'\nend)()\nlocal start=(function()\n'+startup+'\nend)()\nstart(make_api,patch)\n'
    (source/'entry.lua').write_text(entry)
    (HERE/'native-proof.json').write_text(json.dumps(dict(capture=str(capture),capture_code_sha256=a.sha(code),status_registry=hex(profile['status_slot']),status_getter_rva='0x11f11d0',application_registry_read_rva='0x69a01e',duration_read_rva='0x69a148',pins=pins,process_access=False),indent=2)+'\n')
    print('Prepared Tenderizer: two retained native data clones, magazine/sway and shared Acid Storm duration transaction; no deployment.')
if __name__=='__main__':main()
