"""Typed reference census of the supported static data and entity deltas."""
import json
import struct
from functools import lru_cache
from pathlib import Path
import prepare as p

a=p.a
_,_,tm=a.parse_typelib(a.DATA/'dl_library.dl_typelib')
names={a.game_hash(n.strip()):n.strip()for n in a.HASH_NAMES.read_text().splitlines()if n.strip()and not n.startswith('//')}

@lru_cache(None)
def leaves(kind,wanted):
    if kind not in tm:return ()
    out=[]
    for m in tm[kind]['members']:
        if m['type']==wanted:out.extend(m['offset']+i*4 for i in range(m['size']//4))
        elif m['type']in tm:
            size=tm[m['type']]['size']
            if size and m['size']%size==0:
                for i in range(m['size']//size):out.extend(m['offset']+i*size+o for o in leaves(m['type'],wanted))
    return tuple(out)

def main():
    targets={a.game_hash('ProjectileType'):{44},a.game_hash('DamageInfoType'):{135}}
    hits=[];offsets={};entity=p.ENTITY;pos=0;indexed=False
    groups=0
    while pos+28<=len(entity):
        index=None
        if indexed:index=a.u32(entity,pos);pos+=4
        assert entity[pos+4:pos+8]==b'LDLD'
        kind,size=a.u32(entity,pos+12),a.u32(entity,pos+16)
        members=tm.get(kind,{}).get('members',[])
        if index is not None and len(members)==2 and members[1]['type']in tm:
            record=members[1]['type'];stride=tm[record]['size']
            if stride and members[0]['size']%16==0 and members[1]['size']%stride==0:
                groups+=1;offsets[index]={wanted:leaves(record,wanted)for wanted in targets}
                owner_rows={}
                for i in range(members[0]['size']//16):
                    owner,row=struct.unpack_from('<QI',entity,pos+28+i*16)
                    if owner:owner_rows.setdefault(row,[]).append(f'{owner:016X}')
                for wanted,value in targets.items():
                    for row in range(members[1]['size']//stride):
                        for o in offsets[index][wanted]:
                            actual=a.u32(entity,pos+28+members[1]['offset']+row*stride+o)
                            if actual in value:
                                hits.append(dict(kind='component',name=names.get(kind,hex(kind)),row=row,offset=o,
                                    target_type=names.get(wanted,hex(wanted)),value=actual,owners=owner_rows.get(row,[])))
        end=pos+28+size
        if end+8>len(entity):break
        indexed=a.u32(entity,end+4)!=0x444C444C;pos=end
    data=(a.DATA/'generated_entity_deltas.dl_bin').read_bytes();base=28
    pairs=struct.unpack_from('<10Q',data,base)
    maps,settings,components,deltas,values=[(base+pairs[i],pairs[i+1])for i in range(0,10,2)]
    for i in range(maps[1]):
        owner,setting=struct.unpack_from('<QI',data,maps[0]+i*16)
        if not owner:continue
        count,first=struct.unpack_from('<II',data,settings[0]+setting*8)
        for j in range(first,first+count):
            component,first_delta,n=struct.unpack_from('<III',data,components[0]+j*12)
            for k in range(first_delta,first_delta+n):
                field,size,value_at=struct.unpack_from('<III',data,deltas[0]+k*12)
                for wanted,value in targets.items():
                    for o in offsets.get(component,{}).get(wanted,[]):
                        if field<=o and o+4<=field+size and a.u32(data,values[0]+value_at+o-field) in value:
                            hits.append(dict(kind='delta',owner=f'{owner:016X}',component=component,offset=o,
                                target_type=names.get(wanted,hex(wanted)),value=a.u32(data,values[0]+value_at+o-field)))
    settings_hits=[]
    for filename,kind,stride,record in [('projectile','ProjectileSettings',272,'ProjectileInfo'),
        ('damage','DamageSettings',76,'DamageInfo'),('explosion','ExplosionSettings',152,'ExplosionInfo'),('beam','BeamSettings',112,'BeamInfo'),('arc','ArcSettings',104,'ArcInfo')]:
        rows,_,_=a.row_table_records(a.DATA/f'generated_{filename}_settings.dl_bin',a.game_hash(kind),stride,[])
        for wanted,value in targets.items():
            for identity,row in rows.items():
                for o in leaves(a.game_hash(record),wanted):
                    if o==0:continue  # Row identity is not a consumer reference.
                    if a.u32(row,o)in value:settings_hits.append(dict(kind=kind,id=identity,offset=o,target=names.get(wanted,hex(wanted)),value=a.u32(row,o)))
    assert not any(h['kind']=='delta' for h in hits),'An attachment overrides a target reference'
    for h in hits:
        assert all(owner in {'CE063AA33D95A812'}for owner in h['owners']),h
    assert len(hits)==1,hits
    expected={('44',135)}
    assert {(h['id'],h['value'])for h in settings_hits}==expected and all(h['kind']=='ProjectileSettings'for h in settings_hits),settings_hits
    result=dict(result='PASS',component_groups=groups,typed_component_and_delta_references=hits,typed_settings_references=settings_hits,acid_storm_status55_intentionally_shared=True)
    (p.HERE/'consumer-census.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
