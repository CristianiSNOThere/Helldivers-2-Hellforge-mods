"""Bounded startup and companion-order fixtures, plus captured native status emulation."""
import json
import struct
import sys
from pathlib import Path
import verify as v

def main():
    source=v.HERE/'source'
    fixture='local profile=(function()\n'+(source/'profile.lua').read_text()+'\nend)()\n'
    fixture+='local start=(function()\n'+(source/'startup.lua').read_text()+'\nend)()\n'
    fixture+=r'''
local tests=0
for _,mode in ipairs({'success','late_data','absent_data','unknown','bad_exe','gas_ready','gas_late','gas_failed','gas_unknown'})do
 _G.TenderizerArmorV1=nil;_G.SterilizerArmorControlV1=nil;_G.CowboyBingusModLoader=nil
 local tick,calls,previous_calls=0,0,0
 if mode:find('gas_',1,true)then
  _G.CowboyBingusModLoader={modules={['mods/codex/sterilizer_armor_control']=mode=='gas_failed'and 'failed'or 'loaded'}}
  if mode=='gas_ready'then _G.SterilizerArmorControlV1={status=profile.gas_applied}end
  if mode=='gas_unknown'then _G.SterilizerArmorControlV1={status='Applied: unknown'}end
 end
 local function previous(a,b)previous_calls=previous_calls+1;return a,b end
 update=previous
 local function make_api()
  return{module=function(n)return n and 'game'or 'exe'end,now=function()return tick end,
   module_hash=function(n)
    if n=='exe'then return mode=='bad_exe'and 'bad'or 'F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06'end
    return '2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E'
   end}
 end
 local patch={apply=function(api)
  assert(api.kept==_G.TenderizerArmorV1.kept)
  calls=calls+1
  if mode=='unknown'then return false,'unknown row'end
  if mode=='absent_data'or(mode=='late_data'and calls<3)then return false,'found 0. No edit applied.'end
  if mode:find('gas_',1,true)then assert(api.gas_required and _G.SterilizerArmorControlV1.status==profile.gas_applied)else assert(not api.gas_required)end
  api.kept[#api.kept+1]={keep=true};return true,'Applied: fixture'
 end}
 start(make_api,patch)
 for i=1,80 do
  tick=tick+5000
  if mode=='gas_late'and tick>=50000 then _G.SterilizerArmorControlV1={status=profile.gas_applied}end
  local a,b=update('a','b');assert(a=='a'and b=='b')
 end
 assert(previous_calls==80 and update==previous,'Update chain was not restored')
 local state=_G.TenderizerArmorV1
 if mode=='success'or mode=='gas_ready'or mode=='gas_late'then assert(state.active and calls==1 and #state.kept==1)end
 if mode=='late_data'then assert(state.active and calls==3)end
 if mode=='absent_data'then assert(not state.active and calls==8)end
 if mode=='unknown'then assert(not state.active and calls==1)end
 if mode=='bad_exe'then assert(not state.active and calls==0)end
 if mode=='gas_failed'then assert(not state.active and calls==0 and state.status:find('within 120 seconds: Gas Overhaul',1,true))end
 if mode=='gas_unknown'then assert(not state.active and calls==0 and state.status:find('Unsupported Gas Overhaul Applied state',1,true))end
 start(make_api,patch);assert(update==previous,'Duplicate initialization installed')
 collectgarbage('collect');assert(_G.TenderizerArmorV1==state)
 tests=tests+1
end
assert(tests==9)
'''
    v.Lua51().run(fixture.encode(),'@tenderizer-startup-contract.lua')
    sys.path.insert(0,str(v.ROOT/'work/sickle-laser-ar-20261015/research-tools'))
    from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
    from unicorn.x86_const import UC_X86_REG_RCX,UC_X86_REG_RAX,UC_X86_REG_RSI,UC_X86_REG_XMM4
    proof=json.loads((v.HERE/'native-proof.json').read_text())
    capture=Path(proof['capture']);meta=json.loads((capture/'metadata.json').read_text());code=(capture/'game-text.bin').read_bytes()
    assert v.a.sha(code)==proof['capture_code_sha256']
    count=0
    for seconds in [1.0,15.0]:
        emu=Uc(UC_ARCH_X86,UC_MODE_64);base=0x100000000;row=0x200000000
        pages={base+0x11f1100&~4095,base+0x37c5c50&~4095,base+0x69a100&~4095,row}
        for page in pages:emu.mem_map(page,4096)
        getter=code[0x11f11d0-meta['rva']:0x11f11df-meta['rva']]
        emu.mem_write(base+0x11f11d0,getter)
        emu.mem_write(base+0x37c5c50+55*8,struct.pack('<Q',row))
        emu.mem_write(base+0x37c5c50+54*8,struct.pack('<Q',row+256))
        emu.mem_write(row,struct.pack('<I',55));emu.mem_write(row+40,struct.pack('<f',seconds))
        emu.reg_write(UC_X86_REG_RCX,55)
        emu.emu_start(base+0x11f11d0,base+0x11f11de)
        assert emu.reg_read(UC_X86_REG_RAX)==row,'Native status index is not55'
        duration=code[0x69a148-meta['rva']:0x69a14d-meta['rva']]
        emu.mem_write(base+0x69a148,duration);emu.reg_write(UC_X86_REG_RSI,row)
        emu.emu_start(base+0x69a148,base+0x69a14d)
        value=struct.unpack('<f',struct.pack('<I',emu.reg_read(UC_X86_REG_XMM4)&0xffffffff))[0]
        assert value==seconds
        count+=1
    result=dict(result='PASS',startup_cases=9,captured_native_status_cases=count,companion_wait='Gas Overhaul only when detected;120seconds bounded;exact Applied state',process_access=False)
    (v.HERE/'extended-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
if __name__=='__main__':main()
