"""Build immutable Tenderizer individual/22-mod pack and audit the full current set."""
from pathlib import Path
import importlib.util
import io
import json
import struct
import sys
import tempfile
import zipfile
import prepare as p

HERE=p.HERE;ROOT=p.ROOT
sys.path.insert(0,str(ROOT/'work/expanded-stat-editor'))
from lua_runtime import Lua51
spec=importlib.util.spec_from_file_location('sickle_audit',ROOT/'work/sickle-double-edge-20261015/build.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
read_zip=audit.read_zip;inventory=audit.inventory
OUT=ROOT/'outputs/tenderizer-armor-20261015-rev3'
IND=ROOT/'work/rapid-arc-thrower/release-repo'
BASELINE=ROOT/'work/super-earth-arsenal-modpack-repo/Super-Earth-Arsenal-Modpack-v1.0.25.zip'

def write_zip(path,files):
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for name,body in sorted(files.items()):
            entry=zipfile.ZipInfo(name,(2026,10,15,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(entry,body)
    body=buffer.getvalue()
    if path.exists():assert path.read_bytes()==body,'Immutable artifact differs: '+str(path)
    else:path.write_bytes(body)
    return dict(path=str(path),sha256=p.a.sha(body),bytes=len(body))

def main():
    for name in ['validation.json','extended-validation.json','consumer-census.json']:
        assert json.loads((HERE/name).read_text())['result']=='PASS'
    identity=json.loads((HERE/'identity.json').read_text())
    config=json.loads((HERE/'profile.json').read_text())
    # Prove the authored normal/durable damage, other AP angles and all unrelated fields stay stock.
    damage=config['registries'][0];old=bytes.fromhex(damage['original'])
    new=old[:damage['offset']]+bytes.fromhex(damage['bytes'])+old[damage['offset']+len(damage['bytes'])//2:]
    assert struct.unpack_from('<2I',new,4)==(90,30)and struct.unpack_from('<4I',new,12)==(3,3,2,0)
    assert struct.unpack_from('<If',new,44)==(55,1)
    assert all(old[i]==new[i]for i in range(len(old))if i not in set(range(4,8))|set(range(12,20))|set(range(44,52)))
    encoder_spec=importlib.util.spec_from_file_location('tenderizer_encoder',ROOT/'work/flag-mod/BingusSharedLoader-main/scripts/archive.py')
    encoder=importlib.util.module_from_spec(encoder_spec);encoder_spec.loader.exec_module(encoder)
    runtime=Lua51();source=(HERE/'source/entry.lua').read_bytes()
    compiled=runtime.compile(source,'@'+identity['implementation']+'.lua')
    assert compiled==(HERE/'compiled.luac').read_bytes()
    wrapper=('-- HD2-Addon: '+identity['module']+'\nreturn require('+json.dumps(identity['implementation'])+')\n').encode()
    envelope=lambda b:struct.pack('<II',len(b),2)+b
    resources={int(identity['key'],16):envelope(wrapper),int(identity['implementation_key'],16):envelope(compiled)}
    archive=encoder.make_archive(resources)
    stem='Addon/9ba626afa44a3aa3.patch_0'
    manifest=dict(Version='0.1.2',Guid=identity['guid'],Name='Tenderizer Armor Softener v0.1.2',Description=p.DESCRIPTION,
        Options=[dict(Name='Enable Tenderizer Armor Softener',Description=p.DESCRIPTION,Include=['Addon'])])
    files={stem:archive,stem+'.stream':b'',stem+'.gpu_resources':b'',
        'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode(),'README.txt':(p.DESCRIPTION+'\n').encode(),'Source/loader-entry.lua':wrapper}
    for path in (HERE/'source').glob('*.lua'):files['Source/'+path.name]=path.read_bytes()
    for name in ['prepare.py','build.py','core.lua','verify.py','verify_extended.py','census.py','profile.json','identity.json','native-proof.json']:
        files['Source/Preparation/'+name]=(HERE/name).read_bytes()
    baseline=read_zip(BASELINE);pack=dict(baseline);pack_stem='Addon/9ba626afa44a3aa3.patch_3'
    assert not any(n.startswith(pack_stem)for n in pack)
    pack.update({pack_stem:archive,pack_stem+'.stream':b'',pack_stem+'.gpu_resources':b''})
    pack['Source/Tenderizer/entry.lua']=source;pack['Source/Tenderizer/loader-entry.lua']=wrapper
    pm=json.loads(pack['manifest.json']);pm['Version']='1.0.26'
    pm['Description']=p.DESCRIPTION+' Includes all twenty-two mods; Pacifier is included and Punisher Plasma is omitted.'
    for option in pm['Options']:option['Description']=pm['Description']
    pack['manifest.json']=(json.dumps(pm,indent=2)+'\n').encode()
    readme=pack['README.md'].decode().replace('v1.0.25','v1.0.26').replace('twenty-one listed mods','twenty-two listed mods')
    readme=readme.replace('|---|---|\n','|---|---|\n| Tenderizer Armor Softener | '+p.DESCRIPTION+' |\n',1)
    start=readme.index('## Changes in v1.0.26')
    readme=readme[:start]+'## Changes in v1.0.26\n\nAdds Tenderizer Armor Softener. The pack includes 22 mods; Pacifier remains included and Punisher Plasma remains omitted.\n'
    pack['README.md']=readme.encode()
    OUT.mkdir(parents=True,exist_ok=True)
    individual_path=OUT/'Tenderizer-Armor-Softener-v0.1.2-Test.zip'
    pack_path=OUT/'Super-Earth-Arsenal-Modpack-v1.0.26-Tenderizer-Rev3-Test.zip'
    artifacts=[write_zip(individual_path,files),write_zip(pack_path,pack)]
    current=sorted((IND/'mods').glob('*.zip'));assert len(current)==21
    assert any('Sickle'in f.name for f in current)and any('Pacifier'in f.name for f in current)and not any('Punisher'in f.name for f in current)
    seen={};guids=set()
    for path in current:
        current_files=read_zip(path);m=json.loads(current_files['manifest.json'])
        assert m['Guid']not in guids;guids.add(m['Guid'])
        for key,body in inventory(current_files).items():assert key not in seen or seen[key]==body;seen[key]=body
    assert identity['guid']not in guids
    new_resources=inventory(files);old_resources=inventory(baseline);combined=inventory(pack)
    assert not new_resources.keys()&seen.keys()and not new_resources.keys()&old_resources.keys()
    assert all(combined[k]==body for k,body in seen.items())
    assert all(combined[k]==body for k,body in old_resources.items())
    assert all(combined[k]==body for k,body in new_resources.items())
    assert combined.keys()==old_resources.keys()|new_resources.keys()
    assert len(seen)+len(new_resources)==34 and len(combined)==36
    for name,body in baseline.items():
        if name.startswith('Addon/'):assert pack[name]==body,'Previous Addon changed: '+name
    for (key,kind),body in combined.items():
        if kind==encoder.TYPE:runtime.compile(body[8:],f'@audit-{key:016X}.lua')
    assert new_resources[(int(identity['implementation_key'],16),encoder.TYPE)][8:]==compiled
    assert new_resources[(int(identity['key'],16),encoder.TYPE)][8:]==wrapper
    for package in [individual_path,pack_path]:
        with tempfile.TemporaryDirectory(prefix='tenderizer-discovery-')as temp:
            paths=[]
            for name,body in read_zip(package).items():
                if name.startswith('Addon/')and '.patch_'in name and name.rsplit('.patch_',1)[1].isdigit():
                    path=Path(temp)/Path(name).name;path.write_bytes(body);paths.append(path.as_posix())
            fixture='local d=dofile('+json.dumps((ROOT/'work/flag-mod/BingusSharedLoader-main/src/discover.lua').as_posix())+')\n'
            fixture+='local entries,warnings=d.scan('+p.literal(paths)+",d.hasher(require('ffi'),require('bit')),io.open)\n"
            fixture+='local n=0;for _,name in ipairs(entries)do if name=='+json.dumps(identity['module'])+' then n=n+1 end end;assert(n==1,"Tenderizer missing/duplicated")\n'
            runtime.run(fixture.encode(),'@tenderizer-loader-discovery.lua')
    fingerprints={str(path):p.a.sha(path.read_bytes())for path in [p.a.GAME/'bin/helldivers2.exe',p.a.GAME/'data/game/game.dll']}
    assert list(fingerprints.values())==[p.a.SUPPORTED_EXE_SHA,p.a.SUPPORTED_DLL_SHA]
    report=dict(result='PASS',baseline_individuals=21,candidate_individuals=22,individual_resources=34,pack_resources=36,
        differing_payload_collisions=0,all_existing_addon_files_identical=True,compiled_implementation_equal=True,
        real_loader_discovery='PASS individual and combined pack',game_file_fingerprints=fingerprints,artifacts=artifacts,
        startup='NOT RUN',loaded_resource='NOT RUN',gameplay='NOT RUN',deployment=False,settings=False,publication=False)
    previous=json.loads((ROOT/'work/tenderizer-armor-20261015/profile.json').read_text())
    assert config['registries'][1]==previous['registries'][1] and config['pins']==previous['pins']
    old_damage=previous['registries'][0]
    previous_bytes=bytes.fromhex(old_damage['original'])
    old_final=previous_bytes[:old_damage['offset']]+bytes.fromhex(old_damage['bytes'])+previous_bytes[old_damage['offset']+len(old_damage['bytes'])//2:]
    assert new[:4]==old_final[:4] and new[8:]==old_final[8:] and struct.unpack_from('<I',new,4)==(90,)
    assert all(damage[k]==old_damage[k]for k in ['label','id','slot','size','sha','original'])
    assert config['components'][:2]==previous['components'] and len(config['components'])==3
    assert config['components'][2]['label']=='sway' and config['components'][2]['edits']==[{'offset':104,'bytes':struct.pack('<f',0.9).hex()}]
    prior_identity=json.loads((ROOT/'work/tenderizer-armor-20261015/identity.json').read_text())
    assert all(identity[k]==prior_identity[k]for k in ['guid','module','implementation','key','implementation_key','global_name'])
    prior=inventory(read_zip(ROOT/'outputs/tenderizer-armor-20261015-rev1/Tenderizer-Armor-Softener-v0.1.0-Test.zip'))
    assert new_resources.keys()==prior.keys()
    assert {key[0]for key in new_resources if new_resources[key]!=prior[key]}=={int(identity['implementation_key'],16)}
    report['only_new_gameplay_edits_vs_accepted_rev1']=['WeaponDataComponent Tenderizer+104: base sway1.0->0.9','DamageInfo135 normal105->90; durable30 retained']
    report['identity_and_other_registry_profiles_preserved']=True
    (HERE/'artifacts.json').write_text(json.dumps(report,indent=2)+'\n')
    (OUT/'OFFLINE-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
