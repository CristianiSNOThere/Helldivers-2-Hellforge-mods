"""Prepare isolated Sickle source from the accepted startup adapter and extracted data."""
from pathlib import Path
import hashlib
import importlib.util
import json
import struct
import sys
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'work/expanded-stat-editor'))
import audit_data as a

SOURCE = HERE / 'source'
BASE = ROOT / 'work/rapid-arc-thrower/release-repo/source/sai-focus-precision/entry.lua'
ENTITY = (a.DATA / 'generated_entities.dl_bin').read_bytes()
_, _, TYPES = a.parse_typelib(a.DATA / 'dl_library.dl_typelib')

def literal(v):
    if isinstance(v, str): return json.dumps(v)
    if isinstance(v, bool): return str(v).lower()
    if isinstance(v, (int, float)): return repr(v)
    if isinstance(v, list): return '{' + ','.join(literal(x) for x in v) + '}'
    return '{' + ','.join('[' + literal(k) + ']=' + literal(x) for k, x in v.items()) + '}'

def specs():
    result = []
    for name, label, edits in [
        ('WeaponDataComponent', 'spread', [(84, struct.pack('<2f', 0, 0))]),
        ('ProjectileWeaponComponent', 'fire', [(8, struct.pack('<f', 700))]),
        ('WeaponHeatComponent', 'heat', [(116, struct.pack('<f', a.f32(b'\x33\x33\x93\x3f', 0) / 2))]),
    ]:
        records, owners, meta = a.component_records(ENTITY, name, TYPES)
        ids = ['8645F167B3C813A2', '295BEB26DC4F8FF1']
        for identity in ids:
            owner = owners[identity]
            assert [k for k, v in owners.items() if v['record_index'] == owner['record_index']] == [identity]
            changes=list(edits)
            if identity=='295BEB26DC4F8FF1':
                if label=='heat':changes=[]  # Every Double-Edge heat and status field stays stock.
                if label=='fire':changes.append((136,struct.pack('<f',-5)))
            result.append(dict(label=label + ('_sickle' if identity == ids[0] else '_double_edge'),
                group=meta['payload_file_offset']-28, header=ENTITY[meta['payload_file_offset']-28:meta['payload_file_offset']].hex(),
                count=meta['map_count'], stride=meta['stride'], index=owner['record_index'],
                owner=struct.pack('<Q', int(identity, 16)).hex(), sha=a.sha(records[identity]),
                edits=[dict(offset=o, bytes=b.hex()) for o, b in changes if records[identity][o:o+len(b)] != b]))
    return result

def main():
    SOURCE.mkdir(parents=True, exist_ok=True)
    metadata_path = HERE / 'identity.json'
    if not metadata_path.exists():
        metadata_path.write_text(json.dumps(dict(guid=str(uuid.uuid4()), module='mods/codex/sickle_laser_ar',
            global_name='SickleLaserARV1', version='0.1.0'), indent=2)+'\n')
    metadata = json.loads(metadata_path.read_text())
    encoder_spec = importlib.util.spec_from_file_location('sickle_archive', ROOT / 'work/flag-mod/BingusSharedLoader-main/scripts/archive.py')
    encoder = importlib.util.module_from_spec(encoder_spec); encoder_spec.loader.exec_module(encoder)
    metadata['key'] = f"{encoder.resource_hash(metadata['module']):016X}"
    metadata['implementation'] = metadata['module']+'_impl'
    metadata['implementation_key'] = f"{encoder.resource_hash(metadata['implementation']):016X}"
    metadata_path.write_text(json.dumps(metadata, indent=2)+'\n')
    components = specs()
    projectile, _, _ = a.row_table_records(a.DATA/'generated_projectile_settings.dl_bin', a.T_PROJECTILE, 272, [])
    damage, _, _ = a.row_table_records(a.DATA/'generated_damage_settings.dl_bin', a.T_DAMAGE, 76, [])
    assert [k for k, row in projectile.items() if a.u32(row, 60) == 48] == ['149']
    rows, _, _ = a.component_records(ENTITY, 'ProjectileWeaponComponent', TYPES)
    assert sorted(k for k, row in rows.items() if a.u32(row, 0) == 149) == ['295BEB26DC4F8FF1', '8645F167B3C813A2']
    registries = []
    definitions=[]
    for ident,normal,durable in [(48,70,10),(50,70,10),(51,88,14),(52,88,14),(542,15,15),(543,30,30),(544,75,75)]:
        after=struct.pack('<2I',normal,durable)
        if ident==48:after+=struct.pack('<3I',3,3,3)  # Minimum AP3; retain the stock extreme-angle lane.
        definitions.append(('damage',ident,0x37C60C0,damage[str(ident)],4,after))
    for ident in [149,185,219,25]:
        definitions.append(('projectile',ident,0x37C7670,projectile[str(ident)],32,struct.pack('<f',2000)))
    for kind, ident, table, row, offset, after in definitions:
        registries.append(dict(label=kind+'_'+str(ident), id=ident, slot=table+ident*8, size=len(row), sha=a.sha(row),
            offset=offset, bytes=after.hex(), original=row.hex()))
    # Instructions pinned by the supported-build research; checked again in-game before any write.
    pins = []
    for rva, target, opcode in [(0x12A23FD,0x37C60C0,b'\x48\x8d\x0d'), (0x11F8EAE,0x37C60C0,b'\x48\x8d\x0d')]:
        pins.append(dict(rva=rva, bytes=(opcode+struct.pack('<i',target-rva-7)).hex()))
    pins += [dict(rva=0x12A2404,bytes='488b0cc1'),dict(rva=0x12A2479,bytes='660f6e5904'),
             dict(rva=0x12A247E,bytes='660f6e4908')]
    # Exact generated SDK pin bytes for the shared projectile's speed copied at spawn.
    import re
    domain=(ROOT/'work/ar32-pacifier-20261011/HD2Runtime-v0.30.3/domains/projectile_ballistics.lua').read_text()
    for rva in [0x13A9C95,0x13AA0C3]:
        match=re.search(r'\["rva"\]='+str(rva)+r',\["hex"\]="([a-f0-9]+)"',domain)
        assert match, hex(rva)
        pins.append(dict(rva=rva,bytes=match.group(1)))
    native_proof=json.loads((HERE/'native-proof.json').read_text())
    assert native_proof['authored_normal_damage_addend_offset']==136
    pins += [dict(rva=p['rva'],bytes=p['bytes'])for p in native_proof['pins']]
    # Every pin, including inherited ones, now has a fresh authorized code capture.
    capture=Path(native_proof['capture']);code=(capture/'game-text.bin').read_bytes()
    capture_meta=json.loads((capture/'metadata.json').read_text())
    assert a.sha(code)==native_proof['capture_code_sha256']
    for p in pins:
        assert code[p['rva']-capture_meta['rva']:p['rva']-capture_meta['rva']+len(p['bytes'])//2]==bytes.fromhex(p['bytes'])
    config = dict(components=components, registries=registries, pins=pins)
    (HERE/'profile.json').write_text(json.dumps(config,indent=2)+'\n')
    (SOURCE/'profile.lua').write_text('return '+literal(config)+'\n')
    baseline=BASE.read_text(encoding='utf-8')
    api=baseline.split('local patch=(function()')[0].split('local make_api=(function()\n',1)[1]
    api=api.split('    local function u16(s,o)')[0]
    api=api.replace('SaiFocusMemoryInfoV1','SickleLaserMemoryInfoV1')
    api=api.replace('Only the guarded SAI rate, spread, ballistics or Focus block may be written','Only guarded Sickle data fields may be written')
    api += (HERE/'adapter-extra.lua').read_text()+'\n    return api\nend\n'
    (SOURCE/'windows.lua').write_text(api,encoding='utf-8')
    startup=baseline.split('local start=(function()\n',1)[1].rsplit('\nend)()',1)[0]
    startup=startup.replace('SaiFocusModV1','SickleLaserARV1').replace('SaiFocusMod','SickleLaserAR')
    startup=startup.replace("version='0.10'","version='0.1.2'").replace('v0.10 STANDARD 70 / FOCUS 37.5 MRAD / 900 RPM / 1300 M/S / DRAG 1.244 / 90 NORMAL / 21 DURABLE','v0.1.2 MINIMUM AP3; LAS-16 70/10; DOUBLE-EDGE 65/10,65/10,83/14,83/14; ALL 2000 M/S; HEAT SELF-DAMAGE -25%')
    startup=startup.replace('during SAI setup','during Sickle setup')
    startup=startup.replace('local state={version=', 'local state={kept={},version=')
    startup=startup.replace('local api=make_api()', 'local api=make_api()\n            api.kept=state.kept')
    startup=startup.replace('start(make_api,patch)','')
    (SOURCE/'startup.lua').write_text(startup,encoding='utf-8')
    entry='-- HD2-Addon: '+metadata['module']+'\n'
    entry+='local make_api=(function()\n'+api+'\nend)()\n'
    entry+='local profile=(function()\n'+(SOURCE/'profile.lua').read_text()+'\nend)()\n'
    entry+='local patch=(function()\n'+(HERE/'core.lua').read_text()+'\nend)()\n'
    entry+='local start=(function()\n'+startup+'\nend)()\nstart(make_api,patch)\n'
    (SOURCE/'entry.lua').write_text(entry,encoding='utf-8')
    print('Prepared Sickle source', metadata['key'], sum(len(c['edits']) for c in components), 'component edits and',len(registries),'private data rows')

if __name__=='__main__': main()
