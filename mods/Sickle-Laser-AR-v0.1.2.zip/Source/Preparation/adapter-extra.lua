    -- Retained by the public mod state for the entire process lifetime. No executable allocation.
    function api.owned_copy(source)
        assert(api.kept and (#source==76 or #source==272),'Owned-row lifetime unavailable')
        local block=ffi.new('uint64_t[?]',math.ceil(#source/8))
        ffi.copy(block,source,#source)
        local row=ffi.cast('uint8_t *',block)
        assert(api.writable(row,#source),'Owned data row permissions unsupported')
        api.kept[#api.kept+1]=block
        return row
    end
    function api.pointer_bytes(p)
        local value=ffi.new('uintptr_t[1]',ffi.cast('uintptr_t',p))
        return ffi.string(value,8)
    end
    -- Only the reviewed damage and projectile registry slots; RO/RX pages are refused.
    local registry_slots={
        [0x37c6240]=true,[0x37c6250]=true,[0x37c6258]=true,[0x37c6260]=true,
        [0x37c71b0]=true,[0x37c71b8]=true,[0x37c71c0]=true,
        [0x37c7b18]=true,[0x37c7c38]=true,[0x37c7d48]=true,[0x37c7738]=true
    }
    function api.registry_access(module,p)
        module=ffi.cast('uint8_t *',module)
        if not registry_slots[api.distance(p,module)] then return false end
        local info=ffi.new('SickleLaserMemoryInfoV1[1]')
        if k.VirtualQuery(p,ffi.cast('void *',info),ffi.sizeof(info[0]))~=ffi.sizeof(info[0]) then return false end
        return info[0].state==0x1000 and info[0].protection==4
          and (info[0].kind==0x20000 or info[0].kind==0x1000000)
          and api.distance(p,info[0].base)>=0 and api.distance(p,info[0].base)+8<=tonumber(info[0].size)
          and api.identity(p)%8==0
    end
    function api.publish(module,p,expected,replacement)
        if not api.registry_access(module,p) or api.read(p,8)~=api.pointer_bytes(expected) then return false end
        -- An aligned x64 pointer store publishes a completely initialized retained data row.
        ffi.cast('uintptr_t *',p)[0]=ffi.cast('uintptr_t',replacement)
        return api.read(p,8)==api.pointer_bytes(replacement)
    end
