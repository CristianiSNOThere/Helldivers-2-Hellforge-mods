"""Execute the captured native addend transfer/blend instructions in an x64 emulator."""
from pathlib import Path
import json
import struct
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/sickle-laser-ar-20261015/research-tools'))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import UC_X86_REG_R13,UC_X86_REG_RBP,UC_X86_REG_RDX,UC_X86_REG_RDI,UC_X86_REG_RBX,UC_X86_REG_RSP

def main():
    proof=json.loads((HERE/'native-proof.json').read_text())
    capture=Path(proof['capture']);meta=json.loads((capture/'metadata.json').read_text());code=(capture/'game-text.bin').read_bytes()
    profile=json.loads((HERE/'profile.json').read_text())
    rows={s['id']:s for s in profile['registries']if s['label'].startswith('damage_')}
    field=next(c for c in profile['components']if c['label']=='fire_double_edge')['edits']
    addend=next(e for e in field if e['offset']==136)
    assert struct.unpack('<f',bytes.fromhex(addend['bytes']))[0]==-5
    results=[]
    for weapon,ident,expected,ap in [('LAS16',48,(70,10),3),('cold',48,(65,10),3),('warm',50,(65,10),3),('hot',51,(83,14),3),('maximum',52,(83,14),4)]:
        for durability in [0,0.5,1]:
            uc=Uc(UC_ARCH_X86,UC_MODE_64)
            uc.mem_map(0x10000000,0x10000)
            uc.mem_map(0x23C6000,0x1000);uc.mem_write(0x23C6D70,struct.pack('<f',1))
            settings,state,hit,event,stack,lanes=[0x10000000+i*0x1000 for i in range(1,7)]
            uc.mem_write(settings+136,bytes.fromhex(addend['bytes'])if weapon!='LAS16'else struct.pack('<f',0))
            chunks=[(0x61202C,0x612054),(0x13AA943,0x13AA95B),(0x12A266E,0x12A26E1)]
            for first,last in chunks:
                page=first&~4095;uc.mem_map(page,4096)
                uc.mem_write(first,code[first-meta['rva']:last-meta['rva']])
            uc.reg_write(UC_X86_REG_R13,settings);uc.reg_write(UC_X86_REG_RBP,state)
            uc.emu_start(*chunks[0],count=32)
            assert struct.unpack('<2f',uc.mem_read(state+0x54,8))==(0,0),'Damage modifier entered AP fields'
            assert struct.unpack('<2f',uc.mem_read(state+0x5C,8))==((-5 if weapon!='LAS16'else 0),0)
            uc.reg_write(UC_X86_REG_RDX,state);uc.reg_write(UC_X86_REG_RDI,hit)
            uc.emu_start(*chunks[1],count=32)
            assert struct.unpack('<2f',uc.mem_read(hit+0x24,8))==(0,0)
            row=rows[ident];normal,durable=struct.unpack_from('<2I',bytes.fromhex(row['bytes']))
            uc.mem_write(event+0x4C,struct.pack('<f',durability))
            uc.mem_write(event+0x98,struct.pack('<f',normal*(1-durability)+durable*durability))
            uc.mem_write(stack+0x90,struct.pack('<Q',hit+0x24))
            uc.mem_write(stack+0x98,struct.pack('<Q',hit+0x2C))
            uc.mem_write(stack+0x88,struct.pack('<Q',lanes))
            uc.mem_write(stack+0x80,struct.pack('<f',1))
            uc.reg_write(UC_X86_REG_RBX,event);uc.reg_write(UC_X86_REG_RSP,stack);uc.reg_write(UC_X86_REG_RDI,0)
            uc.emu_start(*chunks[2],count=64)
            actual=struct.unpack('<f',uc.mem_read(event+0x98,4))[0]
            target=expected[0]*(1-durability)+expected[1]*durability
            assert abs(actual-target)<0.00001,(weapon,durability,actual,target)
            original=bytearray.fromhex(row['original']);replacement=bytes.fromhex(row['bytes']);original[row['offset']:row['offset']+len(replacement)]=replacement
            assert struct.unpack_from('<3I',original,12)==(ap,ap,ap)
            assert struct.unpack_from('<I',original,24)[0]==0
            results.append(dict(weapon=weapon,durable_fraction=durability,damage_before_armor=actual,armor_penetration_preserved=ap))
    report=dict(result='PASS',native_x64_emulation_cases=len(results),results=results,
        basis='Exact instructions from user-authorized code capture; emulated source-settings copy, spawned-shot copy and native normal/durable blend',
        game_process_access=False,game_writes=False)
    (HERE/'native-emulation.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS:',len(results),'captured native x64 addend/blend cases; damage split and AP separation verified.')

if __name__=='__main__':main()
