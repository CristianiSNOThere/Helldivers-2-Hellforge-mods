"""Resolve concrete remaining gates: actual partial writes and bounded startup dispatch."""
import json
from pathlib import Path
import verify as v

def main():
    source=v.HERE/'source'
    startup='local start=(function()\n'+(source/'startup.lua').read_text()+'\nend)()\n'
    startup+=r'''
local tests=0
for _,mode in ipairs({'success','late','absent','unknown','bad_exe'})do
 _G.SickleLaserARV1=nil
 local tick,calls,previous_calls=0,0,0
 local function previous(a,b)previous_calls=previous_calls+1;return a,b end
 update=previous
 local function make_api()
  return{module=function(n)return n and 'game' or 'exe'end,now=function()return tick end,
   module_hash=function(n)
    if n=='exe'then return mode=='bad_exe'and 'bad' or 'F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06'end
    return '2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E'
   end}
 end
 local patch={apply=function(api)
  assert(api.kept==_G.SickleLaserARV1.kept)
  calls=calls+1
  if mode=='unknown'then return false,'unknown row'end
  if mode=='absent'or(mode=='late'and calls<3)then return false,'found 0. No edit applied.'end
  api.kept[#api.kept+1]={keep=true}
  return true,'Applied: fixture'
 end}
 start(make_api,patch)
 local callback=update
 for i=1,80 do tick=tick+5000;local a,b=update('a','b');assert(a=='a'and b=='b')end
 assert(previous_calls==80 and update==previous,'Update chain was not restored')
 local state=_G.SickleLaserARV1
 if mode=='success'then assert(state.active and calls==1 and #state.kept==1)end
 if mode=='late'then assert(state.active and calls==3)end
 if mode=='absent'then assert(not state.active and calls==8)end
 if mode=='unknown'then assert(not state.active and calls==1)end
 if mode=='bad_exe'then assert(not state.active and calls==0)end
 start(make_api,patch);assert(update==previous,'Duplicate module installed again')
 collectgarbage('collect');assert(_G.SickleLaserARV1==state)
 tests=tests+1
end
assert(tests==5)
'''
    v.Lua51().run(startup.encode(),'@sickle-startup-contract.lua')
    report=dict(result='PASS',transaction_fixtures_with_real_partial_writes=json.loads((v.HERE/'validation.json').read_text())['fixtures'],
        startup_contract_fixtures=5,note='Own process only; startup fixtures do not constitute a live game launch.')
    (v.HERE/'extended-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__=='__main__':main()
