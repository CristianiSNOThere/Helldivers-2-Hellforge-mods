"""Run shipped Sickle Lua in isolated buffers; no external game process access."""
from pathlib import Path
import json
import sys
import struct
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/expanded-stat-editor'))
from lua_runtime import Lua51
import audit_data as a

def long(s):return '[====['+s+']====]'

FIXTURE=r'''
local ffi=require('ffi')
local function file(name)local f=assert(io.open(data_path..'/'..name,'rb'));local s=f:read('*a');f:close();return s end
local entities=file('generated_entities.dl_bin')
local groups={}
for _,s in ipairs(profile.components)do
 if not groups[s.group]then
  local count=s.label:find('spread')and 366 or s.label:find('fire')and 272 or 30
  groups[s.group]=entities:sub(s.group+1,s.group+28+s.count*16+count*s.stride)
 end
end
entities=nil;collectgarbage('collect')
local module=ffi.cast('uint8_t *',0x200000000)
local function bytes(p)local a=ffi.new('uintptr_t[1]',ffi.cast('uintptr_t',p));return ffi.string(a,8)end
local function f32(p,o)return tonumber(ffi.cast('float *',p+o)[0])end
local function u32(p,o)return tonumber(ffi.cast('uint32_t *',p+o)[0])end
local function fixture(read_only)
 collectgarbage('collect')
 local api=make_api();api.kept={}
 local hold={}
 local en=ffi.new('uint8_t[?]',20500000);hold[#hold+1]=en
 local base=ffi.cast('uint8_t *',en)-26151656
 for offset,source in pairs(groups)do ffi.copy(base+offset,source,#source)end
 local owner=ffi.new('uint8_t[8]');hold[#hold+1]=owner
 local ownerp=ffi.cast('uint8_t *',owner)
 local refs={}
 local slots=ffi.new('uint64_t[?]',#profile.registries);hold[#hold+1]=slots
 for i,s in ipairs(profile.registries)do
  local block=ffi.new('uint8_t[?]',s.size);hold[#hold+1]=block
  local p=ffi.cast('uint8_t *',block);ffi.copy(p,unhex(s.original),s.size)
  slots[i-1]=ffi.cast('uintptr_t',p)
  refs[i]={p=p,slot=ffi.cast('uint8_t *',slots)+(i-1)*8,spec=s}
 end
 local native_read=api.read
 api.read=function(p,n)
  if p==module+0x346bf98 then assert(n==8);return bytes(ownerp)end
  if p==ownerp+0xf12bd8 then assert(n==8);return bytes(base+26151684)end
  for _,s in ipairs(profile.pins)do if p==module+s.rva then assert(n==#s.bytes/2);return unhex(s.bytes)end end
  for _,r in ipairs(refs)do if p==module+r.spec.slot then assert(n==8);return native_read(r.slot,n)end end
  return native_read(p,n)
 end
 api.registry_access=function(m,p)
  assert(m==module)
  for _,r in ipairs(refs)do if p==module+r.spec.slot then return true end end
  return false
 end
 api.publish=function(m,p,old,new)
  if not api.registry_access(m,p) or api.read(p,8)~=bytes(old)then return false end
  for _,r in ipairs(refs)do if p==module+r.spec.slot then ffi.cast('uintptr_t *',r.slot)[0]=ffi.cast('uintptr_t',new);return true end end
  return false
 end
 return api,hold,base,refs
end
local function snapshot(api,base,refs)
 local result={}
 for offset,source in pairs(groups)do result[offset]=api.read(base+offset,#source)end
 for i,r in ipairs(refs)do result['row'..i]=api.read(r.p,r.spec.size);result['slot'..i]=api.read(module+r.spec.slot,8)end
 return result
end
local function same(a,b,label)
 for k,v in pairs(a)do assert(v==b[k],label..' changed '..tostring(k))end
end
local count=0
local function reject(label,change)
 local api,hold,base,refs=fixture()
 change(api,base,refs)
 local before=snapshot(api,base,refs)
 local ok,why=patch.apply(api,ffi.cast('void *',module))
 assert(not ok,label..' succeeded unexpectedly')
 same(before,snapshot(api,base,refs),label)
 count=count+1
end
for pass=1,2 do
 local api,hold,base,refs=fixture()
 -- Representative unrelated companion writes before / after setup must survive exactly.
 local other=base+26151656+28+11680+297*1232
 if pass==1 then ffi.cast('float *',other+84)[0]=70 end
 local before=snapshot(api,base,refs)
 assert(patch.apply(api,ffi.cast('void *',module)))
 if pass==2 then ffi.cast('float *',other+84)[0]=70 end
 for _,s in ipairs(profile.components)do
  local p=base+s.group+28+s.count*16+s.index*s.stride
  if s.label:find('spread')then assert(f32(p,84)==0 and f32(p,88)==0)end
  if s.label:find('fire')then assert(f32(p,8)==700)end
  if s.label=='heat_sickle'then assert(math.abs(f32(p,116)-0.575)<0.0000001)end
  if s.label=='heat_double_edge'then assert(f32(p,116)==1.149999976158142)end
  if s.label=='fire_double_edge'then assert(f32(p,136)==-5 and f32(p,128)==0 and f32(p,132)==0 and f32(p,140)==0)end
 end
 assert(f32(base+27493728+28+928+21*592,116)==1.149999976158142,'Double-Edge bullet heat changed')
 assert(f32(base+27493728+28+928+21*592,96)==200,'Double-Edge heat capacity changed')
 assert(#api.kept==11,'Owned row lifetime missing')
 local by_label={}
 for _,r in ipairs(refs)do by_label[r.spec.label]=api.pointer(api.read(module+r.spec.slot,8),0)end
 collectgarbage('collect')
 local expected_damage={{48,70,10,3},{50,70,10,3},{51,88,14,3},{52,88,14,4},{542,15,15,9},{543,30,30,9},{544,75,75,9}}
 for _,v in ipairs(expected_damage)do
  local d=by_label['damage_'..v[1]];assert(u32(d,4)==v[2]and u32(d,8)==v[3]and u32(d,12)==v[4])
 end
 for _,id in ipairs({149,185,219,25})do
  local p=by_label['projectile_'..id];assert(f32(p,32)==2000 and f32(p,40)==0 and f32(p,44)==0)
 end
 assert(u32(by_label.damage_544,44)==5 and f32(by_label.damage_544,48)==10,'Maximum-heat ignition changed')
 assert(#api.kept==11)
 for i,r in ipairs(refs)do assert(api.read(r.p,r.spec.size)==before['row'..i],'Shared authoring row changed')end
 for _,s in ipairs(profile.components)do
  for _,edit in ipairs(s.edits)do
   local offset=s.group+28+s.count*16+s.index*s.stride+edit.offset
   ffi.copy(base+offset,before[s.group]:sub(offset-s.group+1,offset-s.group+#edit.bytes/2),#edit.bytes/2)
  end
 end
 ffi.copy(other+84,groups[26151656]:sub(28+11680+297*1232+85,28+11680+297*1232+88),4)
 for offset,source in pairs(groups)do assert(api.read(base+offset,#source)==source,'Unrelated entity bytes changed')end
 count=count+1
end
for _,label in ipairs({'spread_sickle','spread_double_edge','fire_sickle','fire_double_edge','heat_sickle','heat_double_edge'})do
 for _,s in ipairs(profile.components)do if s.label==label then
  reject(label..' checksum',function(api,base)local row=base+s.group+28+s.count*16+s.index*s.stride;row[0]=(row[0]+1)%256 end)
  reject(label..' duplicate owner',function(api,base)ffi.copy(base+s.group+28,unhex(s.owner),8);ffi.cast('uint32_t *',base+s.group+36)[0]=s.index end)
 end end
end
reject('native pin',function(api)local read=api.read;api.read=function(p,n)if p==module+profile.pins[1].rva then return string.rep('\0',n)end;return read(p,n)end end)
reject('unknown damage',function(api,base,refs)refs[1].p[4]=61 end)
reject('unknown projectile',function(api,base,refs)refs[8].p[32]=1 end)
reject('registry permissions',function(api)api.registry_access=function()return false end end)
reject('component permissions',function(api)api.data_access=function()return false end end)
reject('clone allocation failure',function(api)api.owned_copy=function()error('allocation failed')end end)
reject('clone copy corrupt',function(api)local alloc=api.owned_copy;api.owned_copy=function(s)local p=alloc(s);p[0]=0;return p end end)
reject('precommit ownership race',function(api,base)
 local read=api.read;local seen=0
 api.read=function(p,n)
  if p==module+0x346bf98 then seen=seen+1;if seen==2 then return string.rep('\0',8)end end
  return read(p,n)
 end
end)
for failure=1,5 do
 reject('partial component write '..failure,function(api)
  local write=api.write_attachment;local writes=0
  api.write_attachment=function(p,s)
   writes=writes+1
   if writes==failure then assert(api.write(p,s:sub(1,#s-1)));return false end
   return write(p,s)
  end
 end)
end
for failure=1,#profile.registries do
 reject('publication failure '..failure,function(api)
  local publish=api.publish;local writes=0
  api.publish=function(...)writes=writes+1;if writes==failure then return false end;return publish(...)end
 end)
 reject('publication succeeded but verification failed '..failure,function(api)
  local publish=api.publish;local writes=0
  api.publish=function(...)writes=writes+1;local ok=publish(...);if writes==failure then return false end;return ok end
 end)
end
-- Real adapter, own-process test allocation, RW/RO guards and retained buffers.
do
 ffi.cdef[[void *VirtualAlloc(void *,size_t,uint32_t,uint32_t);int VirtualFree(void *,size_t,uint32_t);]]
 local k=ffi.load('kernel32');local allocation=k.VirtualAlloc(nil,16384,0x3000,4);assert(allocation~=nil)
 local slot=ffi.cast('uint8_t *',allocation);local fake_module=slot-0x37c6240
 local api=make_api();api.kept={}
 local old=api.owned_copy(unhex(profile.registries[1].original));local new=api.owned_copy(unhex(profile.registries[1].original))
 ffi.cast('uintptr_t *',slot)[0]=ffi.cast('uintptr_t',old)
 assert(api.registry_access(fake_module,slot))
 for _,s in ipairs(profile.registries)do assert(api.registry_access(fake_module,fake_module+s.slot),'Missing exact registry slot '..s.label)end
 assert(not api.registry_access(fake_module,fake_module+0x37c60c0+519*8),'General fire registry must be forbidden')
 assert(not api.registry_access(fake_module,slot+8))
 assert(api.publish(fake_module,slot,old,new))
 assert(not api.publish(fake_module,slot,old,new),'stale expected pointer accepted')
 local prior=ffi.new('uint32_t[1]');assert(k.VirtualProtect(slot,4096,2,prior)~=0)
 assert(not api.registry_access(fake_module,slot) and not api.publish(fake_module,slot,new,old))
 assert(k.VirtualProtect(slot,4096,4,prior)~=0)
 assert(api.publish(fake_module,slot,new,old))
 assert(k.VirtualProtect(slot,4096,2,prior)~=0)
 assert(api.write_attachment(slot+16,'\1\2\3\4'))
 assert(not api.writable(slot+16,4),'RO protection not restored')
 assert(k.VirtualFree(allocation,0,0x8000)~=0)
 count=count+1
end
local f=assert(io.open(report_path,'w'));f:write(tostring(count));f:close()
'''

def main():
    source=HERE/'source'
    runtime=Lua51()
    entry=(source/'entry.lua').read_bytes()
    compiled=runtime.compile(entry,'@mods/codex/sickle_laser_ar.lua')
    (HERE/'compiled.luac').write_bytes(compiled)
    config=json.loads((HERE/'profile.json').read_text())
    for pin in config['pins']:
        assert 1 <= len(bytes.fromhex(pin['bytes'])) <= 15
    prefix="local data_path="+long(str(a.DATA).replace('\\','/'))+'\n'
    prefix+='local report_path='+long(str(HERE/'fixture-count.txt').replace('\\','/'))+'\n'
    for var,name in [('make_api','windows.lua'),('profile','profile.lua')]:
        prefix+='local '+var+'=(function()\n'+(source/name).read_text()+'\nend)()\n'
    prefix+="local function unhex(s)return(s:gsub('..',function(h)return string.char(tonumber(h,16))end))end\n"
    prefix+='local patch=(function()\n'+(HERE/'core.lua').read_text()+'\nend)()\n'
    runtime.run((prefix+FIXTURE).encode(),'@sickle-offline-fixtures.lua')
    count=int((HERE/'fixture-count.txt').read_text())
    report=dict(offline='PASS',fixtures=count,compiled_sha256=a.sha(compiled),startup='NOT RUN',loaded_resource='NOT RUN',
        gameplay='NOT RUN',deployment=False,settings=False,external_game_process_access=False,
        scope='LAS-16 70/10 and half heat; Double-Edge 65/10,65/10,83/14,83/14, direct heat damage minus25%; all tiers2000m/s, zero spread/no drag; AP3 minimum with AP4 peak, heat buildup and general fire preserved.',
        native_evidence='Fresh authorized code capture confirms every pin and authored136->runtime92 normal damage addend. Runtime repeats code checks before writes.')
    (HERE/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS:',count,'actual LuaJIT fixtures; exact scope, retained clones, rollback, own-process adapter and compilation.')

if __name__=='__main__':main()
