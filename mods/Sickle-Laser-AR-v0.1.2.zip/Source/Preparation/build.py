"""Build immutable local individual/pack candidates and audit all 21 packages."""
from pathlib import Path
import hashlib
import importlib.util
import json
import struct
import sys
import tempfile
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/expanded-stat-editor'))
from lua_runtime import Lua51
import audit_data as a
import prepare

OUT=ROOT/'outputs/sickle-laser-ar-20261015-rev3'
REPO=ROOT/'work/rapid-arc-thrower/release-repo'
PACK=ROOT/'work/super-earth-arsenal-modpack-repo/Super-Earth-Arsenal-Modpack-v1.0.24.zip'
DESCRIPTION=('LAS-16 Sickle deals 70 normal and 10 durable damage and generates 50% less heat per shot, from 1.15 to 0.575. '
    'LAS-17 Double-Edge Sickle deals 65/10 normal/durable damage cold and warm, then 83/14 at hot and maximum heat. '
    'Both weapons have at least AP3 penetration; Double-Edge reaches AP4 at maximum heat. Both Sickles have a base fire rate of 700 RPM, zero horizontal and vertical spread, '
    'and 2,000 m/s projectiles at every heat tier with no distance damage fall-off. Double-Edge direct heat self-damage is reduced by 25%. '
    'Its heat buildup, cooling and maximum-heat ignition remain unchanged; general fire damage is unchanged.')

def read_zip(p):
    with zipfile.ZipFile(p)as z:
        assert z.testzip()is None
        assert len(z.namelist())==len(set(z.namelist()))
        return {n:z.read(n)for n in z.namelist()if not n.endswith('/')}

def write_zip(p,files):
    import io
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for name,body in sorted(files.items()):
            entry=zipfile.ZipInfo(name,(2026,10,15,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(entry,body)
    data=stream.getvalue()
    if p.exists():assert p.read_bytes()==data,'Immutable artifact differs: '+str(p)
    else:p.write_bytes(data)
    return dict(path=str(p),sha256=a.sha(data),bytes=len(data))

def inventory(files):
    result={}
    for name,data in files.items():
        if not(name.startswith('Addon/') and '.patch_'in name and name.rsplit('.patch_',1)[1].isdigit()):continue
        assert struct.unpack_from('<I',data)[0]==0xF0000011
        types,count=struct.unpack_from('<II',data,4)
        table_end=72+types*32+count*80
        spans=[]
        for i in range(count):
            pos=72+types*32+i*80
            key,kind,offset=struct.unpack_from('<QQQ',data,pos)
            size=struct.unpack_from('<I',data,pos+56)[0]
            assert offset>=table_end and offset+size<=len(data)
            body=data[offset:offset+size]
            identity=(key,kind)
            assert identity not in result
            if kind==0xA14E8DFA2CD117E2:
                length,version=struct.unpack_from('<II',body)
                assert length+8==len(body)and version==2
            result[identity]=body;spans.append((offset,offset+size))
        spans.sort();assert all(x[1]<=y[0]for x,y in zip(spans,spans[1:]))
    return result

def main():
    assert json.loads((HERE/'validation.json').read_text())['offline']=='PASS'
    for name in ['extended-validation.json','native-emulation.json','consumer-census.json']:
        assert json.loads((HERE/name).read_text())['result']=='PASS'
    identity=json.loads((HERE/'identity.json').read_text())
    spec=importlib.util.spec_from_file_location('sickle_encoder',ROOT/'work/flag-mod/BingusSharedLoader-main/scripts/archive.py')
    encoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(encoder)
    lua=Lua51()
    implementation=(HERE/'source/entry.lua').read_bytes()
    compiled=lua.compile(implementation,'@'+identity['implementation']+'.lua')
    wrapper=('-- HD2-Addon: '+identity['module']+'\nreturn require('+json.dumps(identity['implementation'])+')\n').encode()
    def envelope(b):return struct.pack('<II',len(b),2)+b
    resource={int(identity['key'],16):envelope(wrapper),int(identity['implementation_key'],16):envelope(compiled)}
    archive=encoder.make_archive(resource)
    stem='Addon/9ba626afa44a3aa3.patch_0'
    manifest=dict(Version='0.1.2',Guid=identity['guid'],Name='Sickle Laser AR v0.1.2',Description=DESCRIPTION,
        Options=[dict(Name='Enable Sickle Laser AR',Description=DESCRIPTION,Include=['Addon'])])
    files={stem:archive,stem+'.stream':b'',stem+'.gpu_resources':b'',
        'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode(),'README.txt':(DESCRIPTION+'\n').encode(),
        'Source/loader-entry.lua':wrapper}
    for p in (HERE/'source').glob('*.lua'):files['Source/'+p.name]=p.read_bytes()
    for name in ['prepare.py','build.py','core.lua','adapter-extra.lua','identity.json','profile.json','verify.py','verify_extended.py','verify_native.py','native-proof.json','status-scope.json','census.py']:
        files['Source/Preparation/'+name]=(HERE/name).read_bytes()
    baseline=read_zip(PACK);pack=dict(baseline)
    pack_stem='Addon/9ba626afa44a3aa3.patch_2'
    assert not any(n.startswith(pack_stem)for n in pack)
    pack.update({pack_stem:archive,pack_stem+'.stream':b'',pack_stem+'.gpu_resources':b''})
    pack['Source/Sickle/entry.lua']=implementation
    pack['Source/Sickle/loader-entry.lua']=wrapper
    pm=json.loads(pack['manifest.json']);pm['Version']='1.0.25'
    pm['Description']=DESCRIPTION+' Includes all twenty-one mods; Pacifier is included and Punisher Plasma is omitted.'
    for opt in pm['Options']:opt['Description']=pm['Description']
    pack['manifest.json']=(json.dumps(pm,indent=2)+'\n').encode()
    pack['README.md']=pack['README.md']+('\n\n## Sickle Laser AR\n\n'+DESCRIPTION+'\n').encode()
    OUT.mkdir(parents=True,exist_ok=True)
    individual_path=OUT/'Sickle-Laser-AR-v0.1.2-Test.zip'
    pack_path=OUT/'Super-Earth-Arsenal-Modpack-v1.0.25-Sickle-Rev3-Test.zip'
    artifacts=[write_zip(individual_path,files),write_zip(pack_path,pack)]
    current=sorted((REPO/'mods').glob('*.zip'));assert len(current)==20
    assert any('Pacifier'in p.name for p in current)and not any('Punisher'in p.name for p in current)
    seen={};guids=set()
    for p in current:
        f=read_zip(p);m=json.loads(f['manifest.json']);assert m['Guid']not in guids;guids.add(m['Guid'])
        for k,v in inventory(f).items():assert k not in seen or seen[k]==v;seen[k]=v
    assert identity['guid']not in guids
    new=inventory(files);old=inventory(baseline);allpack=inventory(pack)
    assert not new.keys()&seen.keys() and not new.keys()&old.keys()
    assert all(allpack[k]==v for k,v in seen.items())
    assert all(allpack[k]==v for k,v in old.items())
    assert all(allpack[k]==v for k,v in new.items())and allpack.keys()==old.keys()|new.keys()
    for n,b in baseline.items():
        if n.startswith('Addon/'):assert pack[n]==b,'Existing Addon changed: '+n
    for (key,kind),body in allpack.items():
        if kind==encoder.TYPE:lua.compile(body[8:],f'@audit-{key:016x}.lua')
    assert new[(int(identity['implementation_key'],16),encoder.TYPE)][8:]==compiled
    assert new[(int(identity['key'],16),encoder.TYPE)][8:]==wrapper
    previous=inventory(read_zip(ROOT/'outputs/sickle-laser-ar-20261015-rev1/Sickle-Laser-AR-v0.1.0-Test.zip'))
    assert previous.keys()==new.keys()
    assert {k[0]for k in new if new[k]!=previous[k]}=={int(identity['implementation_key'],16)}
    for package in [individual_path,pack_path]:
        with tempfile.TemporaryDirectory(prefix='sickle-discovery-')as temp:
            paths=[]
            for n,b in read_zip(package).items():
                if n.startswith('Addon/')and '.patch_'in n and n.rsplit('.patch_',1)[1].isdigit():
                    p=Path(temp)/Path(n).name;p.write_bytes(b);paths.append(p.as_posix())
            fixture='local d=dofile('+json.dumps((ROOT/'work/flag-mod/BingusSharedLoader-main/src/discover.lua').as_posix())+')\n'
            fixture+='local entries,warnings=d.scan('+prepare.literal(paths)+",d.hasher(require('ffi'),require('bit')),io.open)\n"
            fixture+='local n=0;for _,name in ipairs(entries)do if name=='+json.dumps(identity['module'])+' then n=n+1 end end;assert(n==1,"Sickle discovery missing or duplicated")\n'
            lua.run(fixture.encode(),'@sickle-real-loader-discovery.lua')
    game=Path(r'D:\SteamLibrary\steamapps\common\Helldivers 2')
    fingerprints={str(p):a.sha(p.read_bytes())for p in [game/'bin/helldivers2.exe',game/'data/game/game.dll']}
    assert list(fingerprints.values())==[a.SUPPORTED_EXE_SHA,a.SUPPORTED_DLL_SHA]
    report=dict(result='PASS',baseline_individuals=20,candidate_individuals=21,individual_resource_count=len(seen)+len(new),
        pack_resource_count=len(allpack),new_resources=[f'{k[0]:016X}:{k[1]:016X}'for k in new],
        differing_payload_collisions=0,all_existing_addon_files_identical=True,compiled_implementation_equal=True,
        real_loader_discovery='PASS individual and combined pack',game_file_fingerprints=fingerprints,
        artifacts=artifacts,startup='NOT RUN',loaded_resource='NOT RUN',gameplay='NOT RUN',deployment=False,publication=False,settings=False)
    (HERE/'artifacts.json').write_text(json.dumps(report,indent=2)+'\n')
    (OUT/'OFFLINE-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
